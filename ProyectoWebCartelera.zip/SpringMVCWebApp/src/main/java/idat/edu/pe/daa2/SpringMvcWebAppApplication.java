package idat.edu.pe.daa2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringMvcWebAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringMvcWebAppApplication.class, args);
	}

}
